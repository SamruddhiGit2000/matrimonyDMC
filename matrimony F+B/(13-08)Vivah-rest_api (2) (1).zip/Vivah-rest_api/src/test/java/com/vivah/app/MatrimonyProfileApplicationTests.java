package com.vivah.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MatrimonyProfileApplicationTests {

	@Test
	void contextLoads() {
	}

}
