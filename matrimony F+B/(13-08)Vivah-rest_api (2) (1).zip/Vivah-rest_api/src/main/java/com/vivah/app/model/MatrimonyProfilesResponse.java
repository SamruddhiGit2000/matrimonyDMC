package com.vivah.app.model;
import java.util.List;

public class MatrimonyProfilesResponse {

    private List<MatrimonyProfile> profiles;

	public List<MatrimonyProfile> getProfiles() {
		return profiles;
	}

	public void setProfiles(List<MatrimonyProfile> profiles) {
		this.profiles = profiles;
	}

}
