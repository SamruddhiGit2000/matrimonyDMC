package com.vivah.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MatrimonyProfileApplication {

	public static void main(String[] args) {
		SpringApplication.run(MatrimonyProfileApplication.class, args);
	}

}
